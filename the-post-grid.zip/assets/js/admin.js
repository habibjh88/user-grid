(function (global, $) {
    'use strict';

    

})(this, jQuery);
